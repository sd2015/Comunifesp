package br.com.grupows.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import br.com.grupows.model.logar;;

@Path("/ws")
public class Request {

	@GET
	@Path("/login")
	@Produces("application/json")
	public logar login(){
		return new logar(true);
	}
}
