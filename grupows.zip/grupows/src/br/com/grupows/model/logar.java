package br.com.grupows.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public final class logar {
	
	private Boolean status;

	public logar(Boolean status) {
		super();
		this.status = status;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	
		
}
